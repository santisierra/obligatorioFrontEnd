import Register from './SignUp';
export default Register;
