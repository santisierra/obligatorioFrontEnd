import TotalCalorias from './TotalCalorias';
export default TotalCalorias;
