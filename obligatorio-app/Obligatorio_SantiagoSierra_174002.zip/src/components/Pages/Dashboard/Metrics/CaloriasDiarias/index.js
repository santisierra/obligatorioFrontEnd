import CaloriasDiarias from './CaloriasDiarias';
export default CaloriasDiarias;
