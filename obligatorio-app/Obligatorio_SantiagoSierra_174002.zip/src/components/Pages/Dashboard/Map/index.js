import Map from './Map';
export default Map;
