import ContadorNuevoPlan from './ContadorNuevoPlan';
export default ContadorNuevoPlan;
