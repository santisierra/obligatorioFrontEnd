import RegistroTableRow from "./RegistroTableRow";
export default RegistroTableRow;
