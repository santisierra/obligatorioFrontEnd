import RegistrosTable from "./RegistrosTable";
export default RegistrosTable;
