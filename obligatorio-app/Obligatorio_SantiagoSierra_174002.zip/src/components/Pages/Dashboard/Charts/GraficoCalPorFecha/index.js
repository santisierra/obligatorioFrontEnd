import CalsPorFecha from './GraficoCalPorFecha';
export default CalsPorFecha;
