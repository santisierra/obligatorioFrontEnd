import Bar from './Bars';
export default Bar;
